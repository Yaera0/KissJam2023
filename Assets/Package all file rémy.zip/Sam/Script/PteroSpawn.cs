using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PteroSpawn : MonoBehaviour
{
    //param
    public float mobCap = 1;
    public float mobCount = 0;
    public bool hasAppeared = false;
    [SerializeField] GameObject pterodactylMob;
    GameObject buffer;
    float decompte = 60;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        decompte -= Time.deltaTime;
        if (decompte < 55 && mobCount < mobCap)
        {
            pterodactylMob.GetComponent<PteroMove>().spawner = this.gameObject;
            buffer = pterodactylMob;

            Vector2 randomPos = new Vector2(UnityEngine.Random.Range(9,11), UnityEngine.Random.Range(2,10));

            Instantiate(buffer, randomPos, Quaternion.identity);
            mobCount += 1;

        }
    }
}
