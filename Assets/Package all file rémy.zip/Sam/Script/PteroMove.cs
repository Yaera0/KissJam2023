using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PteroMove : MonoBehaviour
{
    //param
    public GameObject spawner;
    float speed = 5f;
    float speedDown = 3f;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector2.left * speed * Time.deltaTime);
        transform.Translate(Vector2.down * speedDown * Time.deltaTime);
        if (this.transform.position.x < -10 || this.transform.position.y < - 7)
        {
            spawner.GetComponent<PteroSpawn>().mobCount--;
            Destroy(this.gameObject);
            
        }
    }
}
