using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClemMan : MonoBehaviour
{
    [SerializeField] List<GameObject> Queue;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Queue.Count==5)
        {
            foreach (GameObject GO in GameObject.FindGameObjectsWithTag("Quartier"))
            {
                GO.GetComponent<ClementineComponent>().disparition();
            }
        }
    }

    public GameObject assign(GameObject gameOb)
    {

        Queue.Add(gameOb); 
        if (Queue.Count > 1)
        {
            return Queue[Queue.Count - 2];
        }
        else
        {
            return this.gameObject;
        }
        
    }

    public void DestroyQueue()
    {
        foreach (GameObject gameOb in Queue)
        {
            gameOb.GetComponent<ClementineComponent>().inc = -2;
        }
        Queue.Clear();
    }
}
