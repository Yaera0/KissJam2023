using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Control
    [SerializeField] bool clavier;

    //Parameters
    [SerializeField] GameObject player;
    float horVal,verVal;
    float speed = 5;
    public int inc;

    // Start is called before the first frame update
    void Start()
    {
        inc = 0;
        player = this.gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        //Controle
        if(clavier)
        {
            Vector2 pos = transform.position;

                if (Input.GetKey(KeyCode.RightArrow) && pos.x < 8.25f)
                {
                    player.transform.Translate(Vector2.right * speed * Time.deltaTime);
                }
                if (Input.GetKey(KeyCode.LeftArrow) && pos.x > -8.25f)
                {
                    player.transform.Translate(Vector2.left * speed * Time.deltaTime);
                }

                if (Input.GetKey(KeyCode.UpArrow) && pos.y < 4.25f)
                {
                    player.transform.Translate(Vector2.up * speed * Time.deltaTime);
                }
                if (Input.GetKey(KeyCode.DownArrow) && pos.y > -4.25f)
                {
                    player.transform.Translate(Vector2.down * speed * Time.deltaTime);
                }
        }
        else
        {
            Vector2 pos = transform.position;

            horVal = Input.GetAxis("Horizontal");
            if (Input.anyKeyDown || Input.anyKey)
            {
                horVal = 0;
                clavier = true;
            }

            if (Mathf.Abs(horVal) > 0.2)
            {
                if (horVal > 0.2 && pos.x < 8.25f)
                {
                    player.transform.Translate(Vector2.right * speed * Time.deltaTime);
                }
                if (horVal < 0.2 && pos.x > -8.25f)
                {
                    player.transform.Translate(Vector2.left * speed * Time.deltaTime);
                }
            }


            verVal = Input.GetAxis("Vertical");
            if (Input.anyKeyDown || Input.anyKey)
            {
                horVal = 0;
                clavier = true;
            }
                
            if (Mathf.Abs(verVal) > 0.2)
            {
                if (verVal > 0 && pos.y < 4.25f)
                {
                    player.transform.Translate(Vector2.up * speed * Time.deltaTime);
                }
                if (verVal < 0 && pos.y > -4.25f)
                {
                    player.transform.Translate(Vector2.down * speed * Time.deltaTime);
                }
            }
        }

        
    }

    


}
