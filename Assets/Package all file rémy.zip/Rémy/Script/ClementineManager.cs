using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ClementineManager : MonoBehaviour
{
    [SerializeField] List<GameObject> ClementinePos = new List<GameObject>();
    [SerializeField] GameObject clementineQuarterPrefab;
    GameObject buffer;

    //param
    bool canAppear = true;
    int i;
    // Start is called before the first frame update
    void Start()
    {
        i = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (GameObject.FindGameObjectsWithTag("Quartier").Length<7) 
        {
            spawnClementineQuarter(1);
        }
    }

    void spawnClementineQuarter(int numberQuarter)
    {
        for(int i=0;i<numberQuarter; i++)
        {
            ClementinePos[i].transform.position = new Vector3(Random.Range(-7.75f, 7.75f), Random.Range(-3.75f, 3.75f), 0);
            clementineQuarterPrefab.transform.position = ClementinePos[i].transform.position + Random.Range(10,5)*Vector3.up;
            clementineQuarterPrefab.GetComponent<ClementineComponent>().spawnPoint = ClementinePos[i].transform.position;
            buffer = clementineQuarterPrefab;
            Instantiate(buffer);
        }
    }
}
